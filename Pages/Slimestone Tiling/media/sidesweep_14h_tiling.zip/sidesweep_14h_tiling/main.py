import numpy as np
from litemapy import BlockState, Region, Schematic
from scipy.stats import binom


def get_asset_as_region(asset_name: str) -> Region:
    schem = Schematic.load(f"assets/{asset_name}.litematic")
    return next(iter(schem.regions.values()))


MAIN_CORE = get_asset_as_region("Main Core")
MAIN_TILE = get_asset_as_region("Main Tile")
MAIN_END = get_asset_as_region("Main End")
RETURN_CORE = get_asset_as_region("Return Core")
RETURN_TILE = get_asset_as_region("Return Tile")
RETURN_END = get_asset_as_region("Return End")


def paste_region(
    reg1: Region, reg2: Region, offset: tuple[int, int, int] = (0, 0, 0)
) -> None:
    for x, y, z in reg2.block_positions():  # type: ignore
        reg1[x + offset[0], y + offset[1], z + offset[2]] = reg2[x, y, z]


def stack_tiles(
    n_tiles: int, core: Region, tile: Region, end: Region, x: int, y: int, z: int
) -> Region:
    true_width = core.width + n_tiles * tile.width + end.width
    reg = Region(x, y, z, true_width, core.height, core.length)
    paste_region(reg, core)
    paste_region(reg, end, (true_width - RETURN_END.width, 0, 0))
    for k in range(n_tiles):
        paste_region(reg, tile, (core.width + tile.width * k, 0, 0))
    return reg


def make_outlines(width: int, length: int, debris_capacity: int = 5) -> Region:
    reg = Region(0, 0, 0, width, 1, length)
    oak = BlockState("minecraft:oak_leaves", persistent="true")
    spruce = BlockState("minecraft:spruce_leaves", persistent="true")
    # add outer outlines parallel to X-axis
    for x in range(width):
        # spruce lines
        reg[x, 0, 0] = spruce
        reg[x, 0, debris_capacity - 1] = spruce
        reg[x, 0, length - debris_capacity] = spruce
        reg[x, 0, length - 1] = spruce
        # oak lines
        reg[x, 0, debris_capacity] = oak
        reg[x, 0, length - debris_capacity - 1] = oak
    # add inner outlines parallel to X-axis
    for x in range(2, width - 2):
        reg[x, 0, debris_capacity + 10] = oak
        reg[x, 0, length - debris_capacity - 11] = oak
    # add outer outlines parallel to Z-axis
    for z in range(debris_capacity):
        reg[0, 0, z] = spruce
        reg[0, 0, length - 1 - z] = spruce
        reg[width - 1, 0, z] = spruce
        reg[width - 1, 0, length - 1 - z] = spruce
    for z in range(debris_capacity, length - debris_capacity - 1):
        reg[0, 0, z] = oak
        reg[width - 1, 0, z] = oak
    for z in range(debris_capacity + 10, length - debris_capacity - 11):
        reg[2, 0, z] = oak
        reg[width - 3, 0, z] = oak

    return reg


def estimate_debris_trench(W, N, p):
    EY = 0.0

    for k in range(N):
        WlogFk = W * binom.logcdf(k, N, p)
        if abs(WlogFk) > 1e-12:
            EY += 1.0 - np.exp(WlogFk)
        else:
            break

    return min(12, max(3, int(EY + 0.5) + 1))


def stack_world_eater(width: int, length: int) -> Schematic:
    min_width = MAIN_CORE.width + MAIN_END.width
    assert width >= min_width, f"The world eater width must be at least {min_width}"
    min_len = MAIN_CORE.length + RETURN_CORE.length
    assert length >= min_len, f"The world eater must be at least {min_len} long"

    n = (width - min_width) // MAIN_TILE.width
    true_width = min_width + n * MAIN_TILE.width

    schem = Schematic(
        f"14h SSNWE {true_width}x{length}", author="Chronos; Tiled by _spindle_"
    )
    # estimate debris trench width with E(Y), where Y is the max of <true_width> iid random variables from Binom(length, p)
    # p=0.0005 corresponds to the asymptotic spawn rate of debris at y=16 as of 1.21.4
    debris_capacity = estimate_debris_trench(true_width, length, 0.0005)
    main_z_offset = length - MAIN_CORE.length - debris_capacity

    schem.regions["Main"] = stack_tiles(
        n, MAIN_CORE, MAIN_TILE, MAIN_END, 0, 1, main_z_offset
    )
    schem.regions["Return"] = stack_tiles(
        n, RETURN_CORE, RETURN_TILE, RETURN_END, 0, 1, debris_capacity
    )
    schem.regions["Outline"] = make_outlines(true_width, length, debris_capacity)
    return schem


if __name__ == "__main__":
    width, length = map(
        int, input("Enter width and height separated by a space: ").split()
    )
    schem = stack_world_eater(width, length)
    schem.save(path := f"output/{schem.name}.litematic")
    print(f"Saved to '{path}'")
